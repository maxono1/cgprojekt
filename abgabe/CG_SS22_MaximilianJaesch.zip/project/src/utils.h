
namespace Utils {
	float lerp(float a, float b, float f);
}

class utils
{
};
